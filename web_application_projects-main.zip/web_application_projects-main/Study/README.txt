


it is a study website where you can create your personal room and interested people will join you and can have discussion on a specific topic .
it is built on by using django framework of python 

